package com.company;

public class SnakeGame {

    public static void main(String[] args) {
	// write your code here
       new GameFrame();//anonymous game object
    }
}
//hell this is job